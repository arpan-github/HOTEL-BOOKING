package com.book.hotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
