package com.book.hotel.Service;

import com.book.hotel.Entity.User;

public interface UserService {

	void userData(User user);
}
