package com.book.hotel.Service;

import com.book.hotel.Entity.BookHotel;

public interface BookHotelService {

	void saveBookHotel(BookHotel bookHotel);

}
